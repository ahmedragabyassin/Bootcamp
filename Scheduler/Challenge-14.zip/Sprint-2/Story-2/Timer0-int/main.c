/*
 * Timer0-int.c
 *
 * Created: 2/20/2019 6:03:55 PM
 * Author : Yassin
 */ 

#include "Includes/Dio.h"
#include "Includes/OS.h"



int main(void)
{
    DIO_SetPinDirection(LED1,OUT); /* LED 1 */
	DIO_SetPinDirection(LED2,OUT); /* LED 2 */
	DIO_SetPinDirection(LED3,OUT); /* LED 3 */
	DIO_SetPinDirection(LED0,OUT); /* LED 4 */
	/************************************************************************/
	/* Add Tasks to queue                                                   */
	/************************************************************************/
	Scheduler_AddTask(task1,DELAY_SECOND); 
	Scheduler_AddTask(task2,DELAY_HALF_SECOND);
	Scheduler_AddTask(task3,DELAY_750_MS);
	/************************************************************************/
	/* Init Scheduler                                                       */
	/************************************************************************/
	SchedulerInit();
	
	/************************************************************************/
	/* Call Scheduler                                                       */
	/************************************************************************/
	SchedulerStart();
    while (NUM_1)
    {
    }
}

